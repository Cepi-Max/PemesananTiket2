<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

    <div class="row">
        <div class="col-lg-6">
            <h4>Edit Kelas Pesawat</h4>

            <?php if(session('success')): ?>
                <div class="alert alert-success" id="notif">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.kelas_pesawat.update', $kelasPesawat->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label for="nama_kelas" class="form-label">Nama Kelas</label>
                    <input type="text" name="nama_kelas" class="form-control" id="nama_kelas" value="<?php echo e(old('nama_kelas', $kelasPesawat->nama_kelas)); ?>" required>
                </div>

                <button type="submit" class="btn btn-dark">Update</button>
                <a href="<?php echo e(route('admin.kelas_pesawat.index')); ?>" class="btn btn-danger">Kembali</a>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sungkem/www/pemesananTiket-main/resources/views/admin/kelas_pesawat/edit.blade.php ENDPATH**/ ?>