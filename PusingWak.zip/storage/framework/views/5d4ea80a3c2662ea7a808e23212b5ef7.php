<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1 class="mb-4"><?php echo e($title); ?></h1>

    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <div class="card shadow-sm">
        <div class="card-body">
            <form action="<?php echo e(route('admin.kota.update', $kota->slug)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="nama_kota" class="form-label">Nama Kota</label>
                    <input type="text" name="nama_kota" id="nama_kota" class="form-control" value="<?php echo e(old('nama_kota', $kota->nama_kota)); ?>" required>
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-dark">Update</button>
                    <a href="<?php echo e(route('admin.kota.index')); ?>" class="btn btn-danger">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sungkem/www/pemesananTiket-main/resources/views/admin/kota/edit.blade.php ENDPATH**/ ?>