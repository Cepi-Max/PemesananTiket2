<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

    
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Daftar Penerbangan</h4>
        <a href="<?php echo e(route('admin.penerbangan.create')); ?>" class="btn btn-dark">Tambah Penerbangan</a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
        </div>
    <?php endif; ?>

    
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle table-striped mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Slug</th>
                            <th>Berangkat</th>
                            <th>Tiba</th>
                            <th>Jam</th>
                            <th>Bandara Asal</th>
                            <th>Bandara Tujuan</th>
                            <th>Pesawat</th>
                            <th>Harga Dewasa</th>
                            <th>Harga Anak</th>
                            <th>Kapasitas</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $penerbangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($item->slug); ?></td>
                            <td><?php echo e($item->tanggal_berangkat); ?></td>
                            <td><?php echo e($item->tanggal_tiba); ?></td>
                            <td><?php echo e($item->jam_berangkat); ?></td>
                            <td><?php echo e($item->bandaraAsal->nama ?? '-'); ?></td>
                            <td><?php echo e($item->bandaraTujuan->nama ?? '-'); ?></td>
                            <td><?php echo e($item->pesawat->nama ?? '-'); ?></td>
                            <td>Rp <?php echo e(number_format($item->harga_dewasa, 0, ',', '.')); ?></td>
                            <td>Rp <?php echo e(number_format($item->harga_anak, 0, ',', '.')); ?></td>
                            <td><?php echo e($item->maks_penumpang); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('admin.penerbangan.edit', $item->id)); ?>" class="btn btn-warning btn-sm me-1">
                                    <i class="bi bi-pencil-square"></i> Edit
                                </a>
                                <form action="<?php echo e(route('admin.penerbangan.destroy', $item->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="12" class="text-center text-muted py-4">Belum ada data penerbangan.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sungkem/www/pemesananTiket/resources/views/admin/penerbangan/index.blade.php ENDPATH**/ ?>