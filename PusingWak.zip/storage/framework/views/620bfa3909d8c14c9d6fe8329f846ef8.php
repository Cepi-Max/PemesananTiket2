<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Tambah Promo</h2>

    <form action="<?php echo e(route('admin.promo.store')); ?>" method="POST" class="card p-4 shadow-sm">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="kode_promo" class="form-label">Kode Promo:</label>
            <input type="text" name="kode_promo" id="kode_promo" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="jumlah_persen" class="form-label">Diskon (%)</label>
            <input type="number" id="jumlah_persen" name="jumlah_%" min="0" max="100" step="0.01" class="form-control">
        </div>

        <div class="mb-3">
            <label for="jumlah_rp" class="form-label">Diskon (Rp)</label>
            <input type="number" id="jumlah_rp" name="jumlah_rp" min="0" step="0.01" class="form-control">
        </div>

        <button type="submit" class="btn btn-dark">Simpan</button>
    </form>
</div>

<script>
    const persen = document.getElementById('jumlah_persen');
    const rupiah = document.getElementById('jumlah_rp');

    persen.addEventListener('input', function () {
        if (persen.value) {
            rupiah.disabled = true;
        } else {
            rupiah.disabled = false;
        }
    });

    rupiah.addEventListener('input', function () {
        if (rupiah.value) {
            persen.disabled = true;
        } else {
            persen.disabled = false;
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sungkem/www/pemesananTiket/resources/views/admin/promo/create.blade.php ENDPATH**/ ?>