<div class="fixed-plugin">
    
    <div class="card shadow-lg">
      <div class="card-header pb-0 pt-3">
        <div class="float-start">
          <h5 class="mt-3 mb-0">Pengaturan Website</h5>
          
        </div>
        <div class="float-end mt-4">
          <button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
            <i class="material-symbols-rounded">clear</i>
          </button>
        </div>
        <!-- End Toggle Button -->
      </div>
      <hr class="horizontal dark my-1">
      <div class="card-body w-auto pt-sm-3 pt-0">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link rounded m-auto <?php echo e(request()->routeIs('show.bannerSettingForm') ? 'active border-bottom text-dark' : 'text-dark'); ?>" href="<?php echo e(route('show.bannerSettingForm')); ?>">
              <span class="nav-link-text ms-1">Banner</span>
            </a>
          </li>
        </ul>
      </div>
      
    </div>
  </div><?php /**PATH /home/sungkem/www/pemesananTiket/resources/views/admin/layouts/asset/materialUi.blade.php ENDPATH**/ ?>