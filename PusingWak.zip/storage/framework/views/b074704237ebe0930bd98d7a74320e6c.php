<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

 
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0">Daftar Kelas Penerbangan</h4>
            <a href="<?php echo e(route('admin.kelas_pesawat.create')); ?>" class="btn btn-dark">
                Tambah Kelas Penerbangan
            </a>
        </div>
        
        <?php if(session('success')): ?>
            <div id="notif" class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
            </div>
        <?php endif; ?>

        
        <div class="col-lg-12 mt-5">
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Daftar Kelas Pesawat</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Slug</th>
                                    <th>Nama Kelas</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $kelasPesawats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($kelas->slug); ?></td>
                                        <td><?php echo e($kelas->nama_kelas); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('admin.kelas_pesawat.edit', $kelas->id)); ?>" class="btn btn-sm btn-warning me-1">
                                                <i class="bi bi-pencil-square"></i> Edit
                                            </a>
                                            <form action="<?php echo e(route('admin.kelas_pesawat.destroy', $kelas->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus kelas ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="bi bi-trash"></i> Hapus
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">Belum ada data kelas pesawat.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sungkem/www/pemesananTiket/resources/views/admin/kelas_pesawat/index.blade.php ENDPATH**/ ?>