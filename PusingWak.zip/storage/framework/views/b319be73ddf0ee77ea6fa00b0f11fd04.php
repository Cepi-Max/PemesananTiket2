<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">Edit Maskapai</h5>
                </div>
                <div class="card-body">
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" id="notif">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    
                    <form action="<?php echo e(route('admin.maskapai.update', $maskapai->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-3">
                            <label for="nama_maskapai" class="form-label">Nama Maskapai</label>
                            <input type="text" name="nama_maskapai" class="form-control" id="nama_maskapai" value="<?php echo e(old('nama_maskapai', $maskapai->nama_maskapai)); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="logo" class="form-label">Logo Maskapai (Opsional)</label>
                            <input type="file" name="logo" class="form-control" id="logo" accept="image/*">
                            <?php if($maskapai->logo): ?>
                                <div class="mt-2">
                                    <img src="<?php echo e(asset('storage/images/maskapai/' . $maskapai->logo)); ?>" alt="Logo Maskapai" width="120" class="img-thumbnail">
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-warning text-white">Perbarui</button>
                            <a href="<?php echo e(route('admin.maskapai.index')); ?>" class="btn btn-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sungkem/www/pemesananTiket-main/resources/views/admin/maskapai/edit.blade.php ENDPATH**/ ?>