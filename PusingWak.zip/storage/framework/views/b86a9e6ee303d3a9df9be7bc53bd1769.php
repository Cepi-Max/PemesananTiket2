<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Tambah Bandara</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Terjadi kesalahan!</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.bandara.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="nama_bandara" class="form-label">Nama Bandara</label>
            <input type="text" class="form-control" id="nama_bandara" name="nama_bandara" required>
        </div>

        <div class="mb-3">
            <label for="nama_bandara" class="form-label">Kota Bandara</label>
            <select name="id_kota" id="id_kota" class="form-control custom-select <?php $__errorArgs = ['id_kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="" disabled selected>Pilih Kota</option>
                <?php $__currentLoopData = $kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->id); ?>">
                        <?php echo e($k->nama_kota); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

       

        <button type="submit" class="btn btn-dark">Simpan</button>
        <a href="<?php echo e(route('admin.bandara.index')); ?>" class="btn btn-danger">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sungkem/www/pemesananTiket-main/resources/views/admin/bandara/create.blade.php ENDPATH**/ ?>