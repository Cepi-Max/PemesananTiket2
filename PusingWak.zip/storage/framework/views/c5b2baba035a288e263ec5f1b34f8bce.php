<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Daftar Maskapai</h4>
        <a href="<?php echo e(route('admin.maskapai.create')); ?>" class="btn btn-dark">
            Tambah Maskapai
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert" id="notif">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Nama Maskapai</th>
                            <th>Logo</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $maskapis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maskapai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($maskapai->nama_maskapai); ?></td>
                            <td>
                                <img src="<?php echo e($maskapai->logo ? asset('storage/images/maskapai/' . $maskapai->logo) : asset('storage/logos/default.jpg')); ?>" alt="Logo" width="50" class="img-thumbnail">
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(route('admin.maskapai.edit', $maskapai->id)); ?>" class="btn btn-sm btn-warning me-1">
                                    <i class="bi bi-pencil-square"></i> Edit
                                </a>
                                <form action="<?php echo e(route('admin.maskapai.destroy', $maskapai->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus maskapai ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted py-4">Belum ada data maskapai.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sungkem/www/pemesananTiket-main/resources/views/admin/maskapai/index.blade.php ENDPATH**/ ?>