<?php $__env->startSection('content'); ?>
            <div class="card shadow mb-4">
                <div class="card-body">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-md-2 mt-3">
                            <a href="<?php echo e(route('show.article.form')); ?>" class="btn btn-dark btn-sm d-flex align-items-center justify-content-center w-80">
                                <span>Tambah</span>
                            </a>
                        </div>
                        <div class="col-md-4">
                            <form action="#">
                                <?php $__currentLoopData = ['category', 'author']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(request($filter)): ?>
                                        <input type="hidden" name="<?php echo e($filter); ?>" value="<?php echo e(request($filter)); ?>">
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="search-container">
                                    <input type="text" class="search-input" placeholder="cari informasi" id="search" name="search" required autocomplete="off">
                                    <button class="search-button" type="submit">
                                        <i class="fas fa-search"></i>
                                        <span>Cari</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Tabel Desktop -->
            <div class="card shadow d-none d-md-block">
                <div class="card-header bg-dark text-white">
                    <h5 class="card-title mb-0">Daftar informasi</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover text-center">
                            <thead>
                                <?php if($articles->isNotEmpty()): ?>
                                    <tr>
                                        <th style="width: 5%">No</th>
                                        <th style="width: 37%">Judul</th>
                                        <th style="width: 15%">Kategori</th>
                                        <th style="width: 15%">Tgl. Posting</th>
                                        <th style="width: 12%">Admin</th>
                                        <th style="width: 16%">Aksi</th>
                                    </tr>
                                <?php endif; ?>
                            </thead>
                            <tbody>
                                <?php $i = 1 ; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="align-middle"><?= $i++; ?></td>
                                        <td class="align-middle"><b><?php echo e(\Illuminate\Support\Str::limit($article->title, 30)); ?></b></td>
                                        <td class="align-middle bg-<?php echo e($article->article_category->color); ?>">
                                            <a href="/admin/info-list?category=<?php echo e($article->article_category->slug); ?>">
                                                <?php if(isset($article->article_category->name)): ?>
                                                <?php echo e($article->article_category->name); ?>

                                                <?php else: ?>
                                                    <span class="text-muted">kategori tidak ditemukan</span>
                                                <?php endif; ?>
                                                
                                            </a>
                                        </td>
                                        <td class="align-middle"><?= (new DateTime($article->created_at))->format('d F Y'); ?></td>
                                        <td class="align-middle">
                                            <a href="/admin/info-list?admin=<?php echo e($article->author->name); ?>">
                                                <?php echo e($article->author->name); ?>

                                            </a>
                                        </td>
                                        <td class="align-middle">
                                            <div class="d-flex justify-content-center align-items-center gap-2">
                                                <a href="<?php echo e(route('show.article.form', $article->slug)); ?>" class="btn btn-warning btn-sm" title="Edit informasi" data-bs-toggle="tooltip">
                                                    <i class="fas fa-edit"></i>
                                                </a> | <form id="form-delete-<?php echo e($article->slug); ?>" action="<?php echo e(route('article.delete', $article->slug)); ?>" method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?> 
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <button type="button" class="btn-delete btn btn-danger btn-sm" title="Hapus informasi" data-bs-toggle="tooltip" data-id="<?php echo e($article->slug); ?>">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="col-12 text-center py-5">
                                            <i class="material-symbols-rounded text-muted mb-3 fs-1">article</i>
                                            <p class="mb-0 text-muted">Tidak ada informasi ditemukan.</p>
                                        </div>
                                    <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="mt-3">
                    <?php echo e($articles->links()); ?>

            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/sungkem/www/pemesananTiket/resources/views/admin/article/index.blade.php ENDPATH**/ ?>